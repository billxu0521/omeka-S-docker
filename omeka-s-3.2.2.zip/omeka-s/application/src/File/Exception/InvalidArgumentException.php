<?php
namespace Omeka\File\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
