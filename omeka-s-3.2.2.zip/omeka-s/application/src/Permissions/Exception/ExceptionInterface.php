<?php
namespace Omeka\Permissions\Exception;

interface ExceptionInterface
{
}
