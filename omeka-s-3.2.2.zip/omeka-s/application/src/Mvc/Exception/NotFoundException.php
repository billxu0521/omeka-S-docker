<?php
namespace Omeka\Mvc\Exception;

class NotFoundException extends RuntimeException
{
}
